package BusReservationApp.src.bus.reservation.client;
import  BusReservationApp.src.bus.reservation.system.TicketBookingThread;
import BusReservationApp.src.bus.reservation.system.TicketCounter;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        TicketCounter ticketCounter = new TicketCounter();
        System.out.println("Enter the Number of Ticket Availble::");
        int t_c= sc.nextInt();
        ticketCounter.setAvailableSeats(t_c);

        TicketBookingThread t1 = new TicketBookingThread(ticketCounter,"John",2);
        TicketBookingThread t2 = new TicketBookingThread(ticketCounter,"Martin",2);
        TicketBookingThread t3 = new TicketBookingThread(ticketCounter, "PRATHAMESH",2);
        TicketBookingThread t4 = new TicketBookingThread(ticketCounter,"Akshay",6);
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        System.out.println("The NUmber of Ticket Avalible is::"+ticketCounter.getAvailableSeats());
    }
}